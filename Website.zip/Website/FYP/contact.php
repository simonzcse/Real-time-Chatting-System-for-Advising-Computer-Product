<!doctype html>
<html lang="en">

<head>
    <title>PC Building - About US</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/addition.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css"
          integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/3171b0b8ab.js" crossorigin="anonymous"></script>
</head>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-app.js"></script>

<!-- If you enabled Analytics in your project, add the Firebase SDK for Analytics -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-analytics.js"></script>

<!-- Add Firebase products that you want to use -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-database.js"></script>
<script src="fireBaseConfig.js"></script>
<script src="accountManagement.js"></script>
<script src="divControl.js"></script>
<body onload="loadChat()">
<?php
session_start();
include "./login.html";
include "./register.html";
include "./header.php";
include "./navBar.php";
?>


<div class="container-fluid bg-light">
    <div class="row align-content-center justify-content-center" style="height: 700px;">
        <div class="col-4 text-right">
            <img src="https://i.imgur.com/8MA8lII.png" width="200px">
            <h1>PC Building</h1>
        </div>
        <div class="col-4 text-left offset-1">
            <div class="media mb-3">
                <i class="fab fa-facebook-square" style="font-size: 50px; color: #3B5998"></i>
                <div class="media-body ml-2">
                    <h5 class="mt-0">Facebook</h5>
                    <a href="#">IPCompany</a>
                </div>
            </div>
            <div class="media mb-3">
                <i class="fab fa-twitter-square" style="font-size: 50px; color: #55ACEE"></i>
                <div class="media-body ml-2">
                    <h5 class="mt-0">Twitter</h5>
                    <a href="#">IPCompany</a>
                </div>
            </div>
            <div class="media">
                <i class="fab fa-instagram" style="font-size: 50px; color: #125688;"></i>
                <div class="media-body ml-2">
                    <h5 class="mt-0">Instagram</h5>
                    <a href="#">IPCompany</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="container-fluid bg-dark">
    <div class="container">
        <div class="row text-light pb-5">
            <div class="col-6 mt-3 d-flex flex-row">
                <img src="https://i.imgur.com/qZOXoGH.png" width="80px" class="d-none d-md-none d-lg-block"><label
                        class="m-3">
                    <h4>PC Building</h4>
                </label>
            </div>
            <div class="col-6 text-light mt-4">
                <label>
                    <h3>Final Year Project</h3>
                    Title : A Real-time Chatting System for Advising Computer Products
                </label>
            </div>
        </div>
    </div>
</footer>

<!-- Chat bot -->
<script>
    function loadChat() {
        $("#chatbot").load("ChatBot%20UI.html");
    }
</script>
<div id="chatbot"></div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>

<!-- Bootstrap core JavaScript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
</body>


</html>