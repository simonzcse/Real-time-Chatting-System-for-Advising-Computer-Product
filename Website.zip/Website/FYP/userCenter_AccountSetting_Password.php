<!doctype html>
<html lang="en">

<head>
    <title>PC Building - Account Setting(Password)</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/addition.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css"
          integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/3171b0b8ab.js" crossorigin="anonymous"></script>
</head>
<style>
    * {
        box-sizing: border-box;
        margin-bottom: 0rem;
    }
    .title {
        width: 100%;
        height: 50px;
        line-height: 50px;
    }
    input:focus {
        outline-color: #ff9e16;
    }
    input {
        border: 1px solid #9a9a9a;
    }
    button {
        background-color: #ffd25a;
        border:1px solid #a07900;
    }
</style>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-app.js"></script>

<!-- If you enabled Analytics in your project, add the Firebase SDK for Analytics -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-analytics.js"></script>

<!-- Add Firebase products that you want to use -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-database.js"></script>
<script src="fireBaseConfig.js"></script>
<script src="accountManagement.js"></script>
<body onload="loadChat()">
<?php
session_start();
include "./login.html";
include "./register.html";
include "./header.php";
include "./navBar.php";
include "./customerDB.php";
?>

<?php
    $userData = getUserData($_SESSION["userID"]);
?>
<div style="min-height:700px;width: 1000px;margin: 0 auto;">
    <div style="height: 33px; line-height: 33px">
        <a href="./userCenter.php?page=userCenter">User Center</a> <span style="font-size: 10px">></span> <a href="./userCenter_AccountSetting.php?page=userCenter">Account Setting</a><span style="font-size: 10px"> ></span> <span class="text-muted">Change your password</span>
    </div>
    <div class="title mb-2">
        <label style="font-size: 28px">Change your password</label>
    </div>
    <div class="border rounded w-100 p-3" style="height: 500px;">
        <div>
            <lable>If you want to change the password associated with your PCBuilding.com customer account, you can do so below. When you are done, be sure to click the <span class="font-weight-bold">"Submit Changes"</span> button.</lable>
        </div>
        <form action="./userCenter_AccountSetting_action.php" method="post" onsubmit="return changePassword()">
            <div class="mt-5">
                New Password:<br>
                <input type="password" id="pw" name="pw" value="" required><br>
            </div>
            <button class="mt-5 p-2" type="submit">Save Change</button>
        </form>
    </div>
</div>

<!-- Footer -->
<footer class="container-fluid bg-dark mt-5">
    <div class="container">
        <div class="row text-light pb-5">
            <div class="col-6 mt-3 d-flex flex-row">
                <img src="https://i.imgur.com/qZOXoGH.png" width="80px" class="d-none d-md-none d-lg-block"><label
                        class="m-3">
                    <h4>PC Building</h4>
                </label>
            </div>
            <div class="col-6 text-light mt-4">
                <label>
                    <h3>Final Year Project</h3>
                    Title : A Real-time Chatting System for Advising Computer Products
                </label>
            </div>
        </div>
    </div>
</footer>

<!-- Chat bot -->
<script>
    function loadChat() {
        $("#chatbot").load("ChatBot%20UI.html");
    }
</script>
<div id="chatbot"></div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>

<!-- Bootstrap core JavaScript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
</body>


</html>