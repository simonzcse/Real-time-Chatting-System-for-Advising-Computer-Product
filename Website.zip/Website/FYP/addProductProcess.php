<?php session_start(); ?>
<?php
require __DIR__ . '/vendor/autoload.php';
use Kreait\Firebase\Factory;

$name = $_POST["name"];
$type = $_POST["rg1"];
$price = $_POST["price"];
$desc = $_POST["desc"];
$qty = 999;

$customerID = $_SESSION["userID"];
$productID = getProductID();

addProduct($name, $type, $price, $desc, $qty, $customerID, $productID);
?>



<?php
function getProductID()
{
    $factory = (new Factory())
        ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('product/');
    $data = $reference->getValue();
    $id = "";

    foreach ($data as $value){
        $id = $value["id"];
        $id = substr($value["id"], 1, 4);
        $id = $id +1;
    }

    return "p" . $id;
}

function addProduct($name, $type, $price, $desc, $qty, $customerID, $productID) {
    $factory = (new Factory())
        ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('Product Image/');
    $data = $reference->getValue();
    $imgURL = $data["imageURL"];

    $reference = $database->getReference('product/');
    $data = $reference->getValue();
    if ($data != NULL) {
        foreach ($data as $key=>$value){
            $array_count = $key;
        }
        $array_count++;
    }

    $postData = [
        "customerID" => $customerID,
        "QtyInStore" => $qty,
        "description" => $desc,
        "id" => $productID,
        "imgURL" => $imgURL,
        "name" => $name,
        "priceForEach" => $price,
        "type" => $type
    ];

    $postRef = $database->getReference('product/'.$array_count)->set($postData);
    $postRef = $database->getReference('Product Image/')->set(null);
}
?>
<script>
    history.go(-2);
</script>
