<?php session_start(); ?>
<?php
require __DIR__ . '/vendor/autoload.php';
use Kreait\Firebase\Factory;

$name = $_POST["name"];
$type = $_POST["rg1"];
$price = $_POST["price"];
$desc = $_POST["desc"];
$qty = 999;

$customerID = $_SESSION["userID"];
$productID = $_GET["productID"];
$imgURL = $_GET["productImg"] ?? NULL;

addProduct($name, $type, $price, $desc, $qty, $customerID, $productID, $imgURL)
?>



<?php

function addProduct($name, $type, $price, $desc, $qty, $customerID, $productID, $imgURL) {
    $factory = (new Factory())
        ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    if ($imgURL == null) {
        $reference = $database->getReference('Product Image/');
        $data = $reference->getValue();
        $imgURL = $data["imageURL"];
    }
    $index = "";

    $reference = $database->getReference('product/');
    $data = $reference->getValue();
    foreach ($data as $key => $value){
        if ($value["id"] == $productID){
            $index = $key;
        }
    }

    $postData = [
        "customerID" => $customerID,
        "QtyInStore" => $qty,
        "description" => $desc,
        "id" => $productID,
        "imgURL" => $imgURL,
        "name" => $name,
        "priceForEach" => $price,
        "type" => $type
    ];

    $postRef = $database->getReference('product/'.$index)->set($postData);
    $postRef = $database->getReference('Product Image/')->set(null);
}
?>
<script>
    history.go(-2);
</script>