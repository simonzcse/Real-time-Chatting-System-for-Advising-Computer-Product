<!doctype html>
<html lang="en">

<head>
    <title>PC Building - User Order</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/addition.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css"
          integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/3171b0b8ab.js" crossorigin="anonymous"></script>
</head>
<style>
    * {
        box-sizing: border-box;
        margin-bottom: 0rem;
    }
    .title {
        width: 100%;
        height: 50px;
        line-height: 50px;
        animation-name: hello;
        animation-duration: 1s;
    }
    @keyframes hello {
        0% {
            transform: translateX(-50px);
            opacity: 0;
        }
        100% {
            transform: translateX(0px);
            opacity: 1;
        }
    }
    .menu ul li {
        cursor: pointer;
        display: inline-block;
        padding: 5px 20px;
    }

    .menu ul li:hover {
        color: #b17d1e;
        border-bottom: #f1a52b 1px solid;
    }

    .menu_active {
        color: #b17d1e;
        border-bottom: #f1a52b 1px solid;
    }
    .collapsible {
        background-color: #f3f3f3;
        color: black;
        font-weight: 500;
        cursor: pointer;
        line-height: 25px;
        height: 100px;
        width: 100%;
        border: 1px solid #e7e7e7;
        outline: none;
        font-size: 14px;
    }

    .content {
        border: 1px solid #e7e7e7;
        padding: 0 18px;
        max-height: 0;
        overflow: hidden;
        transition: all .6s;

    }
</style>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-app.js"></script>

<!-- If you enabled Analytics in your project, add the Firebase SDK for Analytics -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-analytics.js"></script>

<!-- Add Firebase products that you want to use -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-database.js"></script>
<script src="fireBaseConfig.js"></script>
<script src="accountManagement.js"></script>
<body onload="loadChat()">
<?php
session_start();
include "./login.html";
include "./register.html";
include "./header.php";
include "./navBar.php";
include "./customerDB.php";
?>


<div style="min-height: 800px;width: 1000px;margin: 0 auto;">
    <div style="height: 33px; line-height: 33px">
        <a href="./userCenter.php?page=userCenter">User Center</a> <span style="font-size: 10px">></span> <span class="text-muted">My Order</span>
    </div>
    <div class="title mb-2">
        <label style="font-size: 28px">My Order</label>
    </div>
    <div class="menu">
        <ul style="list-style-type: none;margin-bottom: 0;">
            <li class="menu_active">Orders</li>
            <li>Canceled order</li>
        </ul>
        <hr class="mt-0">
    </div>
    <div class="position-relative">
        <?php 
        getOrders($_SESSION["userID"]);
        ?>
    </div>
</div>

<!-- Footer -->
<footer class="container-fluid bg-dark">
    <div class="container">
        <div class="row text-light pb-5">
            <div class="col-6 mt-3 d-flex flex-row">
                <img src="https://i.imgur.com/qZOXoGH.png" width="80px" class="d-none d-md-none d-lg-block"><label
                        class="m-3">
                    <h4>PC Building</h4>
                </label>
            </div>
            <div class="col-6 text-light mt-4">
                <label>
                    <h3>Final Year Project</h3>
                    Title : A Real-time Chatting System for Advising Computer Products
                </label>
            </div>
        </div>
    </div>
</footer>

<!-- Chat bot -->
<script>
    function loadChat() {
        $("#chatbot").load("ChatBot%20UI.html");
    }
</script>
<div id="chatbot"></div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>

<!-- Bootstrap core JavaScript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script>
    var coll = document.getElementsByClassName("collapsible");
    var i;

    for (i = 0; i < coll.length; i++) {
        coll[i].addEventListener("click", function() {
            this.classList.toggle("active");
            var content = this.nextElementSibling;
            if (content.style.maxHeight === "800px") {
                content.style.maxHeight  = "0";
                content.style.minHeight  = "0";
            } else {
                content.style.maxHeight  = "800px";
            }
        });
    }
</script>
</body>


</html>