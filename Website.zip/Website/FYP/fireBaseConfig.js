var firebaseConfig = {
    apiKey: "AIzaSyAAFpDbQysuICfDTe-8RMxLBqIKr_TCPaI",
    authDomain: "fyp-project-500c0.firebaseapp.com",
    databaseURL: "https://fyp-project-500c0-default-rtdb.firebaseio.com",
    projectId: "fyp-project-500c0",
    storageBucket: "fyp-project-500c0.appspot.com",
    messagingSenderId: "608811553091",
    appId: "1:608811553091:web:eb78cc6a000bb11860dff6",
    measurementId: "G-NLCPDXD46L"
};
firebase.initializeApp(firebaseConfig);
var database = firebase.database();

