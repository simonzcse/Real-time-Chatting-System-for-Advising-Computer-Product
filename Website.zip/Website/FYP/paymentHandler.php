<?php
require __DIR__ . '/vendor/autoload.php';

use Kreait\Firebase\Factory;

$factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
$factory = (new Factory())
    ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

$database = $factory->createDatabase();

$reference = $database->getReference('cart/');
$data = $reference->getValue();

$reference2 = $database->getReference('bill/');
$data2 = $reference2->getValue();
if ($data2) {
    $array_count = count($data2);
} else {
    $array_count = 0;
}

foreach ($data2 as $value) {
    $orderID = substr($value["orderID"], -1);
}

$orderID = str_pad($orderID + 1, 6, '0', STR_PAD_LEFT);

date_default_timezone_set('Asia/Hong_Kong');
$orderDate = date("D, d M y H:i");

$country = $_GET["country"] ?? "Not set";
$city = $_GET["city"] ?? "Not set";
$road = $_GET["road"] ?? "Not set";
$paymethod = $_GET["paymethod"] ?? "Not set";

foreach ($data as $key => $value) {
    
    $customer_id = $value["customer_id"];
    $qty = $value["productForCart"]["Qty"];
    $product_id = $value["productForCart"]["id"];

    $postData = [
        "orderDate" => $orderDate,
        "orderID" => $orderID,
        "customer_id" => $customer_id,
        "paymentType" => $paymethod,
        "productForBill" => [
            "Qty" => $qty,
            "id" => $product_id
        ],
        "deliver_address" => [
            "Country" => $country,
            "City" => $city,
            "Road" => $road
        ],
    ];
    $postRef = $database->getReference('bill/' . $array_count)->set($postData);
    $array_count = $array_count + 1;
    $database->getReference('cart/' . $key)->set(NULL);
}
?>
<script>
    alert("Payment Successful!");
    history.go(-2);
</script>