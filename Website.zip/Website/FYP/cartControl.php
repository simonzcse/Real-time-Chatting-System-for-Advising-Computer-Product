<?php

require __DIR__ . '/vendor/autoload.php';

use Kreait\Firebase\Factory;

function listCart()
{
    $totalPrice = 0;
    $userID = $_SESSION["userID"] ?? NULL;
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
        ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('cart/');
    $data = $reference->getValue();
    $string = '            <table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col"></th>
            <th scope="col">Product Name</th>
            <th scope="col">Quantity</th>
            <th scope="col">Product Price</th>
            <th scope="col"></th>
        </tr>
    </thead>';
    if ($data) {
        foreach ($data as $key => $value) {
            if ($value == null) {
                continue;
            }
            if ($value["customer_id"] == $userID) {
                $productID = $value["productForCart"]["id"];
                $reference2 = $database->getReference('product/');
                $data2 = $reference2->getValue();
                foreach ($data2 as $value2) {
                    if ($value2["id"] == $productID) {
                        $price = $value["productForCart"]["Qty"] * $value2["priceForEach"];
                        $totalPrice += $price;
                        $string .= "<tbody>";
                        $string .= "<tr>";
                        $string .= "<th scope='row'><img src='{$value2["imgURL"]}' width='150px'></th>";
                        $string .= "<td>{$value2["name"]}</td>";
                        $string .= "<td>{$value["productForCart"]["Qty"]}</td>";
                        $string .= "<td>{$value2["priceForEach"]}</td>";
                        $string .= '<form method="POST" action="./removeFormCart.php">';
                        $string .= "<input type='hidden' name='cartID' value='{$key}'>";
                        $string .= '<td class="mt-5"><button type="submit" class="btn btn-outline-danger">';
                        $string .= '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-square-fill" viewBox="0 0 16 16">';
                        $string .= '<path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm3.354 4.646L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 1 1 .708-.708z">';
                        $string .= '</path>';
                        $string .= '</svg>';
                        $string .= 'Cancel';
                        $string .= '</button></form></td>';
                    }
                }
            } else {
                continue;
            }
        }
        $string .= "</tbody></table></div></div>";
        echo $string;
    } else {
        $string .= "<tbody>";
        $string .= "<tr>";
        $string .= "<th><h3>No Result found</h3></th>";
        $string .= "<th style='height: 350px'></th>";
        $string .= "</tr></tbody></table></div></div>";
        echo $string;
    }

    if ($data) {
        echo "<div class='container-fluid round border'><div>";
        echo "<h5><label>Total Price : HKD$ {$totalPrice}</label></h5>";
//        echo '<h5 class="d-inline-block mr-5"><label>Payment</label></h5>';
//        echo '<img src="https://i.imgur.com/jbjjvWr.png" width="100px" data-toggle="modal" data-target="#exampleModalCenter" style="cursor: pointer;">
//        <img src="https://i.imgur.com/ypj541D.png" width="130px"  data-toggle="modal" data-target="#exampleModalCenter" style="cursor: pointer;">
//        <img src="https://i.imgur.com/ewkWpoT.png" width="150px"  data-toggle="modal" data-target="#exampleModalCenter" style="cursor: pointer;">
//        </div></div>';
        echo '
                <a id="checkout" class="btn btn-success mb-5" href="./paymentProcess.php">
            <label>Proceed to Checkout</label>
            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-cart" viewBox="0 0 16 16">
                <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
            </svg>
        </a>
        ';
        echo "</div></div>";
    }
}


