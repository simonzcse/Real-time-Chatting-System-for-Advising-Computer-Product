<?php
date_default_timezone_set('Asia/Hong_Kong');
$a = date("D, d M y H:i");
var_dump($a);
?>