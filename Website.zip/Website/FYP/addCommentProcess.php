<?php
require __DIR__ . '/vendor/autoload.php';

use Kreait\Firebase\Factory;

$factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
$factory = (new Factory())
    ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

$database = $factory->createDatabase();

$reference = $database->getReference('userComments/');
$data = $reference->getValue();

if ($data) {
    $array_count = count($data);
} else {
    $array_count = 0;
}

$comment = $_GET["comment"] ?? NULL;
$productID = $_GET["productID"] ?? NULL;
$customerID = $_GET["customerID"] ?? NULL;


$postData = [
    "comment" => $comment,
    "productID" => $productID,
    "customerID" => $customerID,
];
$postRef = $database->getReference('userComments/' . $array_count)->set($postData);
?>

<script>
    history.go(-1);
</script>
