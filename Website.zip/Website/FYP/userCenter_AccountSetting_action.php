<?php
session_start();
include "./customerDB.php";
$value = getUserData($_SESSION["userID"]);
$userData = getUserData($_SESSION["userID"]);


$f_name = $_POST["f_name"] ?? NULL;
$l_name = $_POST["l_name"] ?? NULL;
$pw = $_POST["pw"] ?? NULL;
$email = $_POST["email"] ?? NULL;
$city = $_POST["city"] ?? NULL;
$country = $_POST["country"] ?? NULL;
$road = $_POST["road"] ?? NULL;


if ($f_name && $l_name) {
    upDateData($customer_id = $value["customer_id"],$email_id = $value["email_id"], $first_name = $f_name ,$last_name = $l_name,  $imageURL = $value["imageURL"], $password = $value["password"]);
}elseif ($f_name) {
    upDateData($customer_id = $value["customer_id"],$email_id = $value["email_id"], $first_name = $f_name ,$last_name = $value["last_name"],  $imageURL = $value["imageURL"], $password = $value["password"]);
}elseif ($l_name) {
    upDateData($customer_id = $value["customer_id"],$email_id = $value["email_id"], $first_name = $value["first_name"] ,$last_name = $l_name,  $imageURL = $value["imageURL"], $password = $value["password"]);
}

if ($pw) {
    upDateData($customer_id = $value["customer_id"],$email_id = $value["email_id"], $first_name = $value["first_name"] ,$value["last_name"],  $imageURL = $value["imageURL"], $password = $pw);
}

if ($email) {
    upDateData($customer_id = $value["customer_id"],$email_id = $email, $first_name = $value["first_name"] ,$value["last_name"],  $imageURL = $value["imageURL"], $password = $value["password"]);
}

if ($city) {
    $address = array();
    $address["city"] = $city;
    $address["country"] = $country;
    $address["road"] = $road;
    upDateData($customer_id = $value["customer_id"],$email_id = $value["email_id"], $first_name = $value["first_name"] ,$last_name = $value["last_name"],  $imageURL = $value["imageURL"], $password = $value["password"], $address);
}
?>
<script>
    alert("Change Successful!");
    history.go(-2);
</script>
