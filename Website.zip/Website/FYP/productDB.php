<?php

require __DIR__ . '/vendor/autoload.php';

use Kreait\Firebase\Factory;

function listProduct($select, $seach) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
            ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('product/');
    $data = $reference->getValue();

    foreach ($data as $key => $value) {
        if ($seach) {
            $productName = $value["name"];
            $pos = strstr(strtoupper($productName), strtoupper($seach));
            if (($select == "AllProduct" || $value["type"] == $select ) && $pos != false) {
                echo "<a href='productPage.php?productID={$value["id"]}&selectOption={$select}&page=productList' class='mb-4 col-12 row media shadow p-3 text-decoration-none text-dark' style='min-width: 500px; height: 180px'>";
                echo '<div class="col-9 d-flex flex-row">';
                echo "<img class='mr-3' src='{$value["imgURL"]}' width='150px'>";
                echo '<div class="media-body">';
                echo "<h5 class='mt-0'>{$value["name"]}</h5>";
                echo "<label>Description : {$value["description"]}</label><br>";
                echo '</div>';
                echo '</div>';
                echo '<div class="col-3">';
                echo '<span class="badge badge-success w-100">';
                echo '<h6>Price</h6>';
                echo '</span>';
                echo '<label class="text-danger">';
                echo "<h4>HKD$ {$value["priceForEach"]}</h4>";
                echo '</label>';
                echo '</div>';
                echo '</a>';
            }
        } else {
            if ($select == "AllProduct" || $value["type"] == $select) {
                echo "<a href='productPage.php?productID={$value["id"]}&selectOption={$select}&page=productList' class='mb-4 col-12 row media shadow p-3 text-decoration-none text-dark' style='min-width: 500px; height: 180px'>";
                echo '<div class="col-9 d-flex flex-row">';
                echo "<img class='mr-3' src='{$value["imgURL"]}' width='150px'>";
                echo '<div class="media-body">';
                echo "<h5 class='mt-0'>{$value["name"]}</h5>";
                echo "<label>Description : {$value["description"]}</label><br>";
                echo '</div>';
                echo '</div>';
                echo '<div class="col-3">';
                echo '<span class="badge badge-success w-100">';
                echo '<h6>Price</h6>';
                echo '</span>';
                echo '<label class="text-danger">';
                echo "<h4>HKD$ {$value["priceForEach"]}</h4>";
                echo '</label>';
                echo '</div>';
                echo '</a>';
            }
        }
    }
}

function getProduct($productID) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
            ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('product/');
    $data = $reference->getValue();

    $reference = $database->getReference('product/');
    foreach ($data as $key => $value) {
        if ($value["id"] != $productID) {
            continue;
        } else {
            echo '<div class="col-lg-9 col-12 p-4">';
            echo '<div class="shadow" style="height: auto;">';
            echo '<div class="bg-info d-inline-block p-2 mt-4"><a class="text-light text-decoration-none" onclick="history.go(-1)" style="cursor: pointer;">Previous page&nbsp;</a></div>';
            echo '<div class="row mt-4">';
            echo '<div class="col-xl-2 col-lg-3 text-center">';
            echo "<img src='{$value["imgURL"]}' width='220px'>";
            echo '<label class="text-danger mt-3">';
            echo "<h4>HKD \${$value["priceForEach"]}</h4>";
            echo '</label>';
            echo '</div>';
            echo '<div class="col-7">';
            echo '<label class="p-2">';
            echo "<h4>Product : {$value["name"]}</h4>";
            echo '</label><br><br>';
            echo "<label style='font-size: 19px;' class='text-muted'>{$value["description"]}</label><br>";
            echo "<label style='font-size: 19px;' class='text-muted'>Inventory : {$value["QtyInStore"]}</label><br>";
            echo '</div>';
            echo '</div>';
            echo '<div class="container-fluid mt-2">';
            if (isset($_SESSION["userID"])) {
                echo "<form method='POST' action='./addtoCartProcess.php'>";
                echo "<input type='hidden' name='productID' value='{$value["id"]}'>";
                echo "<input type='hidden' name='productName' value='{$value["name"]}'>";
                echo '<label style="font-size: 20px;">Quantity</label>';
                echo '<input type="number" name="qty" min="1"  class="form-control w-25 d-inline-block" required>';
                echo "<button type='submit' class='btn btn-block btn-primary text-light mt-2'>Add to cart</button></form>";
            } else {
                echo '<button class="btn btn-block btn-primary text-light" data-toggle="modal" data-target="#login">Add to cart</button>';
            }
            echo '</div><br>';
            echo '</div>';
            if (isset($_SESSION["userID"])) {
                echo "
                    <div style='height: 150px;width: 100%;' class='mt-5 mb-4 p-2'>
                        <form method='get' action='./addCommentProcess.php'>
                            <label class='text-muted'>Leave your comment</label><br>
                            <input type='hidden' name='productID' value='{$value["id"]}'>
                            <input type='hidden' name='customerID' value='{$_SESSION["userID"]}'>
                            <input type='text' name='comment' id='comment' required autocomplete='off'>
                            <button class='btn btn-secondary mt-3' type='submit'>Leave a Comment</button>
                        </form>
                    </div>
                ";
            }else {
                echo '
                <div style="height: 150px;width: 100%;" class="position-relative mt-5 mb-4">
                    <hr>
                    <label class="text-muted" id="commentRequired">You must login to leave a comment.</label>
                </div>
                ';
            }
            echo '<div style="max-height: 800px; overflow: auto">';
            listComments($value["id"]);
            echo "</div>";
            echo "</div>";
            echo '</div>';
        }
    }
}

function getProductByID($productID) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
            ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('product/');
    $data = $reference->getValue();
    foreach ($data as $key => $value) {
        if ($value["id"] == $productID) {
            echo "
            <div class='col-2'>
            <img src={$value["imgURL"]} width='150px'>
            </div>
            <div class='col-7' style='height: 150px;'>
            <label class='text-muted' style='font-size: 19px'>{$value["name"]}</label><br>
            <label class='text-danger'>HKD$ {$value["priceForEach"]}</label>
            <form action='./computerBuildRecord.php' method='get'>
                <input type='hidden' value={$value["id"]} name='productID'>
                <input type='hidden' value='true' name='removeSession'>
                <input type='hidden' value={$value["type"]} name='productType'>
                <button class='btn btn-block btn-outline-danger'>Cancel</button>
            </form>
            </div>
            ";
            return $value["priceForEach"];
        }
    }
}

function getProductByType($type) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
            ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('product/');
    $data = $reference->getValue();
    foreach ($data as $key => $value) {
        if ($value["type"] == $type) {
            echo "<div class='col-3 border text-center rounded' style='height: 320px'>";
            echo "<img class='mt-3' src={$value["imgURL"]} height='150px' width='200px'>";
            echo "<h6 class='mt-4'>{$value["name"]}</h6>";
            echo "<a class='btn btn-block btn-success' href='./computerBuildRecord.php?productID={$value["id"]}&productType={$value["type"]}'>Select</a>";
            echo "<div class='text-left text-danger' style='font-size: 20px'>";
            echo "HKD$ {$value["priceForEach"]}";
            echo "</div>";
            echo "</div>";
        }
    }
}

function getProductData($productID = null, $productName = null) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
            ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('product/');
    $data = $reference->getValue();
    foreach ($data as $value) {
        if ($value["id"] == $productID || $value["name"] == $productName) {
        $array = array();
        $array["id"] = $value["id"];
        $array["QtyInStore"] = $value["QtyInStore"];
        $array["description"] = $value["description"];
        $array["imgURL"] = $value["imgURL"];
        $array["name"] = $value["name"];
        $array["priceForEach"] = $value["priceForEach"];
        $array["type"] = $value["type"];
        
        return $array;
        }
    }
    return "Product Not Found!";
}

function listComments($productID) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
        ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('userComments/');
    $data = $reference->getValue();

    foreach ($data as $value) {
        if ($value["productID"] == $productID) {
            $userData = getUserData2($value["customerID"]);
            echo "
                <div style='height: 150px' class='border p-3 mb-3'>
                    <div class='float-left mr-4'>
                        <img src='https://i.imgur.com/E4lqTkM.png' height='118px'>
                    </div>
                    <div class='float-left'>
                        <h5><label>{$userData["username"]}</label></h5>
                        {$value["comment"]}
                    </div>
                </div>
            ";
        }
    }
}

function getUserData2($userID) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
        ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('customer/');
    $data = $reference->getValue();

    foreach ($data as $value) {
        if ($value["customer_id"] == $userID) {
            $array = array();
            $array["customer_id"] = $value["customer_id"];
            $array["first_name"] = $value["first_name"];
            $array["last_name"] = $value["last_name"];
            $array["email_id"] = $value["email_id"];
            $array["password"] = $value["password"];
            $array["imageURL"] = $value["imageURL"];
            $array["address"] = $value["address"];
            $array["username"] = $value["username"];
            return $array;
        }
    }
    return "User Not found!";
}

function getCustomerProducts() {
    $factory = (new Factory())
        ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $customerID = $_SESSION["userID"];
    $count = 0;

    $reference = $database->getReference('product/');
    $data = $reference->getValue();
    foreach ($data as $value){
        if ($customerID == $value["customerID"]) {
            if ($count == 0){
                echo '<div class="d-flex justify-content-between mt-4 mb-4 flex-wrap">';
            }
            echo "
                <div>
                    <div class='products'>
                        <div class='information' style='transition:all .5s'>
                            <div class='p-2'>
                                <h5 class='text-muted' style='height: 45px'>{$value["name"]}</h5><hr>
                                <img src={$value["imgURL"]} width='150px'>
                            </div>
                        </div>
                        <div class='desc_information' style='transition:all .5s'>
                            <div class='p-2'>
                                <label class='text-muted' style='font-size: 20px'>Description</label>
                                <label class='text-justify text-muted'>{$value["description"]}</label>
                            </div>
                        </div>
                        <div class='products_price'>
                            <label class='mr-3 float-right text-white' style='transform: translateY(100px);font-size: 25px'>HKD \${$value["priceForEach"]}</label>
                        </div>
                    </div>
                    <div>
                        <a class='btn btn-block' style='background-color: #FFDD26' href='userCenter_ProductEditor.php?productID={$value["id"]}'>EDIT</a>
                    </div>
                </div>
            ";
            $count+= 1;
            if ($count >= 4){
                echo '</div>';
                $count = 0;
            }
        }
    }
    echo '</div>';

}