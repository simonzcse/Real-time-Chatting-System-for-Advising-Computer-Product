

function signInWithEmailPassword(email, password) {
    firebase.auth().signInWithEmailAndPassword(email, password)
        .then((user) => {
            var user = firebase.auth().currentUser;
            if (user) {
                window.location.href = "./index.php?userID=" + user.uid;
            }
        })
        .catch((error) => {
            var errorCode = error.code;
            var errorMessage = error.message;
            alert(errorMessage);
        });
}

function signUpWithEmailPassword(firstname, lastname, password, email) {
    firebase.auth().createUserWithEmailAndPassword(email, password)
        .then(cred => {
            var user = firebase.auth().currentUser;
            writeUserData(user.uid, firstname, lastname, password, email);
            signInWithEmailPassword(email, password);
        })
        .catch((error) => {
            var errorCode = error.code;
            var errorMessage = error.message;
            alert(errorMessage);
        });
}

function login() {

    var userEmail = document.getElementById("email").value;
    var userPass = document.getElementById("password").value;

    signInWithEmailPassword(userEmail, userPass);
}

function logout() {
    firebase.auth().signOut();
    window.location = "./index.php?logout=true";
}

function createUser() {
    var firstname = document.getElementById("register_fn").value;
    var lastname = document.getElementById("register_ln").value;
    var password = document.getElementById("register_password").value;
    var email = document.getElementById("register_email").value;
    if (firstname == "" || lastname == "") {
        alert("You must fill in all data!");
        return false;
    }
    signUpWithEmailPassword(firstname, lastname, password, email);
}

function getUserCount() {
    var ref = firebase.database().ref("customer/");
    ref.once("value")
        .then(function (snapshot) {
            return snapshot.numChildren();
        });
}

function writeUserData(userId, firstname, lastname, password, email) {
    //alert("userID : "+ userId + "firstname: " + firstname + "lastname : " + lastname + "password" + password + "email" + email);
    var ref = firebase.database().ref("customer/");
    ref.once("value")
        .then(function (snapshot) {
            var count = snapshot.numChildren();
            firebase.database().ref('customer/' + userId).set({
                "address": {"city":"No City", "country":"No Country", "road":"No Road"},
                customer_id: userId,
                role: "Customer",
                mobile: "81777778",
                status: "off",
                first_name: firstname,
                last_name: lastname,
                email_id: email,
                password: password,
                username: firstname + " " + lastname,
                imageURL: "https://upload.wikimedia.org/wikipedia/commons/8/81/Linea_1.png"
            });
        });
}

function changePassword() {
    var user = firebase.auth().curresntUser;
    var newPassword = document.getElementById("pw").value;

    user.updatePassword(newPassword).then(function() {
        return true;
    }).catch(function(error) {
        var errorCode = error.code;
        var errorMessage = error.message;
        alert(errorMessage);
        return false;
    });
}

function changeEmail() {
    var user = firebase.auth().currentUser;
    var newEmail = document.getElementById("pw2").value;

    user.updateEmail(newEmail).then(function() {
        return true;
    }).catch(function(error) {
        var errorCode = error.code;
        var errorMessage = error.message;
        alert(errorMessage);
        return false;
    });

}

function resetPassword() {
    var auth = firebase.auth();
    var emailAddress = document.getElementById("emailAddress1").value;

    auth.sendPasswordResetEmail(emailAddress).then(function() {
        alert("Email sended");
    }).catch(function(error) {
        var errorCode = error.code;
        var errorMessage = error.message;
        alert(errorMessage);
    });
}