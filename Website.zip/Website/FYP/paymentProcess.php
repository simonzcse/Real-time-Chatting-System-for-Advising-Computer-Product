<?php
session_start();
?>
<!doctype html>
<html lang="en">

<head>
    <title>PC Building - About US</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/addition.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css"
          integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/3171b0b8ab.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-app.js"></script>

<!-- If you enabled Analytics in your project, add the Firebase SDK for Analytics -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-analytics.js"></script>

<!-- Add Firebase products that you want to use -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-database.js"></script>
<script src="fireBaseConfig.js"></script>
<script src="accountManagement.js"></script>
<script src="divControl.js"></script>
<style>
    * {
        margin: 0;
        box-sizing: border-box;
    }
    input[type=radio] {
        cursor: pointer;
        top: 0;
        left: 0;
        position: absolute;
        display: block;
        width: 100%;
        height: 100%;
        -webkit-appearance: none;
        z-index: 0;
    }

    input[type=radio]:hover {
        background-color: rgba(0,0,0,0.05);
    }

    #addressSetting input[type=radio]:checked {
        border: 1px solid #61b6ff;
    }
    #addressSetting input[type=radio]:focus {
        outline: none;
    }
    #addressSetting input[type=text] {
        border: 1px solid gray;
        position: absolute;
        border-radius: 8px;
        padding: 3px;
        width: 250px;
    }
    #addressSetting input[type=text]:focus {
        outline: none;
        border: 1px solid #000000;
    }
    .title {
        padding: 10px;
        width: 100%;
        height: 60px;
        background-color: rgb(15,27,59)
    }
    #addressSetting {
        border: 5px dashed #c6c6c6;
        width: 100%;
        height: 350px;
    }
    #addressSetting > div {
        position: relative;
        width: 45%;
        height: 90%;
        border: 1px solid gray;
    }
    .addressLabel {
        padding: 10px;
    }
    .addressLabel label {
        font-weight: 500;
        display: inline-block;
        width: 150px;
    }
    .methods {
        position: relative;
        width: 100%;
        height: 70px;
        border: 1px solid #e2e2e2;
    }
    .methods input[type=radio]:checked {
        border: 1px solid #61b6ff;
    }
    .methods input[type=radio]:focus {
        outline: none;
    }
</style>
<script>
    $(document).ready(function () {
        $("#op1").click(function () {
            $("#text1").prop('required',true);
            $("#text2").prop('required',true);
            $("#text3").prop('required',true);
        })
        $("#op2").click(function () {
            $("#text1").prop('required',false);
            $("#text2").prop('required',false);
            $("#text3").prop('required',false);
        })
        $("#form1").submit(function () {
            $('#exampleModalCenter').modal('show');
            if($('#op1').is(':checked')) {
                var country = $("#text1").val();
                var city = $("#text2").val();
                var road = $("#text3").val();
            }else if ($('#op2').is(':checked')) {
                var country = $("#text4").val();
                var city = $("#text5").val();
                var road = $("#text6").val();
            }
            if ($('#op3').is(':checked')) {
                var method = $("#op3").val();
            }else if ($('#op4').is(':checked')) {
                var method = $("#op4").val();
            }
            $("#lb1").val(country);
            $("#lb2").val(city);
            $("#lb3").val(road);
            $("#lb4").val(method);
        })
    })
</script>
<body onload="loadChat()">

<?php
include "./customerDB.php";
?>

<?php
$userData = getUserData($_SESSION["userID"]);
?>
<form method="get" action="test.php" onsubmit="return false" id="form1">
    <div class="float-left" style="width: 70%;">
        <div class="title">
            <h3 class="text-light"><label>PC Building</label></h3>
        </div>
        <div class="p-3">
            <div style="height: 33px; line-height: 33px">
                <a href="./shoppingCart.php?page=shoppingCart">Shopping cart</a> <span style="font-size: 10px">></span> <a class="text-muted">Payment Process</a><span style="font-size: 10px">
            </div>
            <h4>Select Deliver Address</h4>
            <div id="addressSetting" class="p-3 d-flex justify-content-around">
                <div class="p-2">
                    <input type="radio" name="radioG1" value="option1" id="op1">
                    <h4 class="text-muted mb-3">New Address</h4>
                    <div class="addressLabel">
                        <label>Select Country</label>
                        <input type="text" name="country1" id="text1" required="true">
                    </div>
                    <div class="addressLabel">
                        <label>Select City</label>
                        <input type="text" name="city1" id="text2" required="true">
                    </div>
                    <div class="addressLabel">
                        <label>Select Road</label>
                        <input type="text" name="road2" id="text3" required="true">
                    </div>
                </div>
                <div class="p-2">
                    <input type="radio" name="radioG1" value="option2" id="op2">
                    <h4 class="text-muted mb-3">Account Setting</h4>
                    <div class="addressLabel">
                        <label>Select Country</label>
                        <input type="text" name="country2" id="text4" value="<?= $userData["address"]["country"] ?>" readonly >
                    </div>
                    <div class="addressLabel">
                        <label>Select City</label>
                        <input type="text" name="city2" id="text5" value="<?= $userData["address"]["city"] ?>" readonly>
                    </div>
                    <div class="addressLabel">
                        <label>Select Road</label>
                        <input type="text" name="road2" id="text6" value="<?= $userData["address"]["road"] ?>" readonly>
                    </div>
                </div>
            </div>
            <h4 class="mt-5">Select Payment Method</h4>
            <div class="mt-4">
                <div class="paymentMethod">
                    <div class="methods mb-3">
                        <input type="radio" name="radioG2" id="op3" value="PayPal" required>
                        <img src="https://i.imgur.com/3RLGAF7.png" height="60px" class="ml-5">
                    </div>
                    <div class="methods">
                        <input type="radio" name="radioG2" id="op4" value="MasterCard / Visa">
                        <img src="https://i.imgur.com/IfzxAEE.png" height="60px" class="ml-5">
                    </div>
                </div>
            </div>
        </div>
        <div style="height: 200px;background-image: url('https://i.imgur.com/N6Qggku.jpg');background-position: center center;background-repeat: no-repeat" class="mt-5">
        </div>
    </div>
    <div class="bg-light d-inline-block p-2 position-fixed" style="width: 30%;height: 1000px;">
        <?php
        paymentListCart();
        ?>
        <button type='submit' class='btn btn-success btn-block'><h5>CHECKOUT</h5></button>
    </div>

</form>

<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Payment</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="get" action="./paymentHandler.php">
                    <h6>Deliver Address :</h6>
                    <div class="form-group row">
                        <label for="" class="col-sm-2 col-form-label">Country: </label>
                        <div class="col-sm-10">
                            <input type="text" id="lb1" name="country" class="text-muted form-control-plaintext" value="" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-sm-2 col-form-label">City: </label>
                        <div class="col-sm-10">
                            <input type="text" id="lb2" name="city" class="text-muted form-control-plaintext" value="" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-sm-2 col-form-label">Road: </label>
                        <div class="col-sm-10">
                            <input type="text" id="lb3" name="road" class="text-muted form-control-plaintext" value="" readonly>
                        </div>
                    </div>
                    <h6>Payment Method :</h6>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <input type="text" id="lb4" name="paymethod" class="text-muted form-control-plaintext" value="" readonly>
                        </div>


                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Payment Confirm</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Chat bot -->
<script>
    function loadChat() {
        $("#chatbot").load("ChatBot%20UI.html");
    }
</script>
<div id="chatbot"></div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>

<!-- Bootstrap core JavaScript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
</body>


</html>