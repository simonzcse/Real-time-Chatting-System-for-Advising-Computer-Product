<?php
    function productGuideControl($value1, $value2){
        if ($value1 == $value2) {
            return "list-group-item-dark";
        }else{
            return "";
        }
    }

?>