<?php
include_once "./productDB.php";

if (!(isset($_SESSION["totalPrice"]))){
    $_SESSION["totalPrice"] = 0;
}

if (!(isset($_SESSION["shopCart"]))){
    $_SESSION["shopCart"] = array();
}

session_start();
$productID = $_GET["productID"] ?? NULL;
$productType = $_GET["productType"] ?? NULL;
$action = $_GET["removeSession"] ?? NULL;

$array = $_SESSION["shopCart"];
$product = getProductByID($productID);

if ($action) {
    unset($_SESSION[$productType]);
    $_SESSION["totalPrice"] -= $product;
    unset($array[$productID]);
    $_SESSION["shopCart"] = $array;
    header("Location: ./computerBuild.php?page=computerBuilder");
}else {
    $_SESSION[$productType] = $productID;
    $array[$productID] = $productID;
    $_SESSION["shopCart"] = $array;
    $_SESSION["totalPrice"] += $product;
    header("Location: ./computerBuild.php?page=computerBuilder");
}
