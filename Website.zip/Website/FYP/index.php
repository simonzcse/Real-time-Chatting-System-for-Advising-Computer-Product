<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
    <title>PC Building</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/addition.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css"
          integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
</head>
<style>
    .media:hover {
        background-color: rgb(240, 240, 240);
        transition: all 0.4s;
    }

    #img2 {
        display: none;
    }

    #chatbot:hover :nth-child(2) {
        display: block;
    }

    .registerForm > div > input:focus {
        border-color: rgba(126, 239, 104, 0.8);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(126, 239, 104, 0.6);
        outline: 0 none;
    }
</style>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-app.js"></script>

<!-- If you enabled Analytics in your project, add the Firebase SDK for Analytics -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-analytics.js"></script>

<!-- Add Firebase products that you want to use -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-database.js"></script>
<script src="fireBaseConfig.js"></script>
<script src="accountManagement.js"></script>
<body onload="loadChat()">
<?php
include "./login.html";
include "./register.html";
include "./header.php";
include "./navBar.php";
?>
<?php
$userID = $_GET["userID"] ?? NULL;
$logout = $_GET["logout"] ?? NULL;
if ($userID) {
    $_SESSION["userID"] = $userID;
    ?>
    <script>
        window.location.href = "./index.php";
    </script>
    <?php
}
if ($logout) {
    session_destroy();
    ?>
    <script>
        window.location.href = "./index.php";
    </script>
    <?php
}
?>
<!-- Carousel -->
<div id="Carousel" class="carousel slide d-none d-md-block" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#Carousel" data-slide-to="0" class="active"></li>
        <li data-target="#Carousel" data-slide-to="1"></li>
        <li data-target="#Carousel" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="https://i.imgur.com/sKkYC8Q.png" class="d-block w-100" height="600px">
        </div>
        <div class="carousel-item">
            <img src="https://i.imgur.com/NMRZ7Qs.jpg" class="d-block w-100" height="600px">
        </div>
        <div class="carousel-item">
            <img src="https://i.imgur.com/nq0lzNt.png" class="d-block w-100" height="600px">
        </div>
    </div>
    <a class="carousel-control-prev" href="#Carousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#Carousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<!-- Carousel - Phone Size -->
<div id="carouselExampleIndicators" class="carousel slide d-md-none d-block" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="https://i.imgur.com/sKkYC8Q.png" class="d-block w-100" height="25%">
        </div>
        <div class="carousel-item">
            <img src="https://i.imgur.com/NMRZ7Qs.jpg" class="d-block w-100" height="25%">
        </div>
        <div class="carousel-item">
            <img src="https://i.imgur.com/nq0lzNt.png" class="d-block w-100" height="25%">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<!-- Products -->
<div class="container">
    <div class="text-dark mt-3 mb-3">
        <h2>New product</h2>
    </div>
    <div class="row">
        <ul class="list-unstyled">
            <li class="media p-3 mb-4" style="border: 1px solid rgb(212, 212, 212); border-radius: 5px;">
                <img class="mr-3 col-3" src="https://i.imgur.com/D0nwEFN.png">
                <div class="media-body col-9">
                    <h5 class="mt-0 mb-1">GeForce RTX 3090</h5>
                    The GeForce RTX™ 3090 is a big ferocious GPU (BFGPU) with TITAN class performance. It’s powered by
                    Ampere—NVIDIA’s 2nd gen RTX architecture—doubling down on ray tracing and AI performance with
                    enhanced Ray
                    Tracing (RT) Cores, Tensor Cores, and new streaming multiprocessors. Plus, it features a staggering
                    24 GB of
                    G6X memory, all to deliver the ultimate gaming experience.
                    <button class="btn btn-success btn-block mt-2">View</button>
                </div>
            </li>
            <li class="media p-3 mb-4" style="border: 1px solid rgb(212, 212, 212); border-radius: 5px;">
                <img class="mr-3 col-3" src="https://i.imgur.com/Q8h5B2Q.png">
                <div class="media-body col-9">
                    <h5 class="mt-0 mb-1">GeForce RTX 3080</h5>
                    The GeForce RTX™ 3080 delivers the ultra performance that gamers crave, powered by Ampere—NVIDIA’s
                    2nd gen
                    RTX architecture. It’s built with enhanced RT Cores and Tensor Cores, new streaming multiprocessors,
                    and
                    superfast G6X memory for an amazing gaming experience.
                    <button class="btn btn-success btn-block mt-2">View</button>
                </div>
            </li> 
            <li class="media p-3" style="border: 1px solid rgb(212, 212, 212); border-radius: 5px;">
                <img class="mr-3 col-3" src="https://i.imgur.com/j4WkIgt.png">
                <div class="media-body col-9">
                    <h5 class="mt-0 mb-1">Ryzen9-5950X</h5>
                    Debuting in AMD Ryzen™ 5000 Series desktop processors, the "Zen 3" architecture is a ground-up
                    redesign of
                    the legendary "Zen” family. Equipped with end-to-end design enhancements, "Zen 3" embodies AMD’s
                    relentless
                    focus on single-core performance, energy efficiency, and reduced latencies. It’s at the core of the
                    best
                    gaming processors in the world1.
                    <button class="btn btn-success btn-block mt-2">View</button>
                </div>
            </li>
        </ul>
    </div>
</div>

<!-- Footer -->
<footer class="container-fluid bg-dark mt-5">
    <div class="container">
        <div class="row text-light pb-5">
            <div class="col-6 mt-3 d-flex flex-row">
                <img src="https://i.imgur.com/qZOXoGH.png" width="80px" class="d-none d-md-none d-lg-block"><label
                        class="m-3">
                    <h4>PC Building</h4>
                </label>
            </div>
            <div class="col-6 text-light mt-4">
                <label>
                    <h3>Final Year Project</h3>
                    Title : A Real-time Chatting System for Advising Computer Products
                </label>
            </div>
        </div>
    </div>
</footer>

<!-- Chat bot -->
<script>
    function loadChat() {
        $("#chatbot").load("ChatBot%20UI.html");
    }
</script>
<div id="chatbot"></div>


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>

<!-- Bootstrap core JavaScript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

</body>
</html>