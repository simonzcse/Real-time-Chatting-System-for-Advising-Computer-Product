<?php
    session_start();
    if (isset($_GET['requested'])&&(isset($_SESSION[$_GET['requested']]))) {
        // return requested value
        print $_SESSION[$_GET['requested']];
    } 
?>