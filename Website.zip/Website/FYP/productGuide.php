<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
    <title>PC Building - Product Guide</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/addition.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css"
          integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
</head>
<style>
    .media:hover {
        background-color: rgb(240, 240, 240);
        transition: all 0.4s;
    }

    #img2 {
        display: none;
    }

    #chatbot:hover :nth-child(2) {
        display: block;
    }

    #filter:hover {
        color: gray;
    }
</style>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-app.js"></script>

<!-- If you enabled Analytics in your project, add the Firebase SDK for Analytics -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-analytics.js"></script>

<!-- Add Firebase products that you want to use -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-database.js"></script>
<script src="fireBaseConfig.js"></script>
<script src="accountManagement.js"></script>

<body onload="loadChat()">
<?php
include "./login.html";
include "./register.html";
include "./header.php";
include "./navBar.php";
include "./productDB.php";
include "./UIControl.php";
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-3 d-lg-block d-none">
            <!-- Guide List -->
            <div class="list-group overflow-auto" style="max-height: 800px">
                <a href="#" class="list-group-item list-group-item-action disabled bg-light text-dark"><strong>
                        <h4>Hardware</h4>
                    </strong></a>
                <?php
                $_GET["selectOption"] = $_GET["selectOption"] ?? "AllProduct";
                ?>
                <a href="./productGuide.php?selectOption=AllProduct&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("AllProduct", $_GET["selectOption"]) ?>">All
                    Product</a>
                <a href="./productGuide.php?selectOption=CPU&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("CPU", $_GET["selectOption"]) ?>">CPU</a>
                <a href="./productGuide.php?selectOption=Motherboard&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Motherboard", $_GET["selectOption"]) ?>">Motherboard</a>
                <a href="./productGuide.php?selectOption=RAM&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("RAM", $_GET["selectOption"]) ?>">RAM</a>
                <a href="./productGuide.php?selectOption=Case&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Case", $_GET["selectOption"]) ?>">Case</a>
                <a href="./productGuide.php?selectOption=Power&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Power", $_GET["selectOption"]) ?>">Power
                    Supply</a>
                <a href="./productGuide.php?selectOption=GPU&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("GPU", $_GET["selectOption"]) ?>">GPU</a>
                <a href="./productGuide.php?selectOption=Storage&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Storage", $_GET["selectOption"]) ?>">Storage</a>

                <a href="./productGuide.php?selectOption=Heatsink&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Heatsink", $_GET["selectOption"]) ?>">Heatsink</a>
                <a href="./productGuide.php?selectOption=Thermal Compound&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Thermal Compound", $_GET["selectOption"]) ?>">Thermal
                    Compound</a>
                <a href="./productGuide.php?selectOption=Water Cooling&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Water Cooling", $_GET["selectOption"]) ?>">Water
                    Cooling Kits</a>
                <a href="#" class="list-group-item list-group-item-action disabled bg-light text-dark"><strong>
                        <h4>Software</h4>
                    </strong></a>
                <a href="./productGuide.php?selectOption=OS System&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("OS System", $_GET["selectOption"]) ?>">Operating
                    System</a>
                <a href="./productGuide.php?selectOption=Office Suites&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Office Suites", $_GET["selectOption"]) ?>">Office
                    Suites</a>
                <a href="#" class="list-group-item list-group-item-action disabled bg-light text-dark"><strong>
                        <h4>Peripherals</h4>
                    </strong></a>
                <a href="./productGuide.php?selectOption=Keyboard&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Keyboard", $_GET["selectOption"]) ?>">Keyboard</a>
                <a href="./productGuide.php?selectOption=Mouse&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Mouse", $_GET["selectOption"]) ?>">Mouse</a>
                <a href="./productGuide.php?selectOption=Mouse Pad&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Mouse Pad", $_GET["selectOption"]) ?>">Mouse
                    Pads</a>
                <a href="./productGuide.php?selectOption=Speakers&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Speakers", $_GET["selectOption"]) ?>">Speakers</a>
                <a href="./productGuide.php?selectOption=Headsets&page=productList"
                   class="list-group-item list-group-item-action <?= productGuideControl("Headsets", $_GET["selectOption"]) ?>">Headsets</a>
            </div>
        </div>
        <!-- Product List -->
        <div class="col-lg-9 col-12 p-4 overflow-auto" style="max-height: 800px">
            <div>
                <h2><?= $_GET["selectOption"] ?></h2>
                <hr>
                <form class="form-group" method="get" action="productGuide.php">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                <button class="input-group-text" id="basic-addon1" type="submit">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                       class="bi bi-search" viewBox="0 0 16 16">
                    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
                  </svg>
                  </button>
                        </div>
                        <?php
                            if ($_GET["selectOption"] != "AllProduct") {
                                echo "
                                    <input type='hidden' value={$_GET['selectOption']} name='selectOption'>
                                ";
                            }
                        ?>
                        <input type="hidden" value="productList" name="page">
                        <input type="text" class="form-control w-50" placeholder="Search Product" name="seachName" aria-describedby="basic-addon1">
                    </div>
                </form>
                <div class="mt-2" id="accordion">
                    <button type="button" class="btn" id="filter" data-toggle="collapse" data-target="#collapseOne"
                            aria-expanded="true" aria-controls="collapseOne">
                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="20" fill="currentColor"
                             class="bi bi-filter-left" viewBox="0 0 16 16">
                            <path d="M2 10.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5z">
                            </path>
                        </svg>
                        <span>
                Filter
              </span>
                    </button>
                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                        <div class="card-body">
                            <div class="container-fluid row text-center">
                                <div class="col-12 col-md-3">
                                    <h6>Price</h6>
                                    <hr>
                                    <form class="text-left">
                                        <button class="text-muted btn btn-outline-ilght w-25">Highest</button>
                                        <br>
                                        <button class="text-muted btn btn-outline-light">Lowest</button>
                                    </form>
                                </div>
                                <div class="col-12 col-md-3">
                                    <h6>Date</h6>
                                    <hr>
                                    <form class="text-left">
                                        <button class="text-muted btn btn-outline-light">Latest</button>
                                        <br>
                                        <button class="text-muted btn btn-outline-light">Oldest</button>
                                    </form>
                                </div>
                                <div class="col-12 col-md-3">
                                    <h6>View count</h6>
                                    <hr>
                                    <form class="text-left">
                                        <button class="text-muted btn btn-outline-light">Highest</button>
                                        <br>
                                        <button class="text-muted btn btn-outline-light">Lowest</button>
                                    </form>
                                </div>
                                <div class="col-12 col-md-3">
                                    <h6>Rank</h6>
                                    <hr>
                                    <form class="text-left">
                                        <button class="text-muted btn btn-outline-light">Highest</button>
                                        <br>
                                        <button class="text-muted btn btn-outline-light">Lowest</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <!-- Product List -->
            <?php
            $seach = $_GET["seachName"] ?? NULL;
            $select = $_GET["selectOption"] ?? "AllProduct";
            echo "<div class='row p-3'>";
            listProduct($select, $seach);
            echo "</div>";
            ?>
        </div>
    </div>
</div>

<!--  <!-- Footer -->-->
<!--  <footer class="container-fluid bg-dark mt-5">-->
<!--    <div class="container">-->
<!--      <div class="row text-light pb-5">-->
<!--        <div class="col-6 mt-3 d-flex flex-row">-->
<!--          <img src="https://i.imgur.com/qZOXoGH.png" width="80px" class="d-none d-md-none d-lg-block"><label class="m-3">-->
<!--            <h4>PC Building</h4>-->
<!--          </label>-->
<!--        </div>-->
<!--        <div class="col-6 text-light mt-4">-->
<!--          <label>-->
<!--            <h3>Final Year Project</h3>-->
<!--            Title : A Real-time Chatting System for Advising Computer Products-->
<!--          </label>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
<!--  </footer>-->

<!-- Chat bot -->
<script>
    function loadChat() {
        $("#chatbot").load("ChatBot%20UI.html");
    }
</script>
<div id="chatbot"></div>


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>

<!-- Bootstrap core JavaScript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
</body>
</html>