<style>
    #userControl a {
        display: block;
        margin: 0;
        width: 100%;
        height: 40px;
        line-height: 40px;
    }

    #userControl a:hover {
        background-color: rgb(236, 236, 236);
    }
</style>

<!-- Header -->
<nav class="navbar navbar-dark w-100" style="background-color: rgb(15,27,59)">
  <div class="row container-fluid">
    <div class="col-4">
      <img src="https://i.imgur.com/qZOXoGH.png" style="width: 80px;" class=" d-none d-sm-none d-md-none d-lg-inline-block">
      <a class="navbar-brand" href="index.php">
        <h2>PC Building</h2>
      </a>
    </div>
    <div class="col-4 text-center d-inline-block">
      <form class="form-inline d-none d-sm-none d-md-block d-lg-block">
        <input class="form-control w-75" type="text" placeholder="Search" aria-label="Search" style="border-radius: 7px 0px 0px 7px">
        <button class="btn btn-success" type="submit" style="margin-left: -4.15px;border-radius: 0px 7px 7px 0px">
          <i class="fa fa-search" aria-hidden="true" style="color: white;"></i>
        </button>
      </form>
    </div>
    <div class="col-4 text-right position-relative">
      <a class="navbar-brand" id="userIf" href="#">
        <svg class="bi bi-person-circle" width="35px" height="35px" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
          <path d="M13.468 12.37C12.758 11.226 11.195 10 8 10s-4.757 1.225-5.468 2.37A6.987 6.987 0 0 0 8 15a6.987 6.987 0 0 0 5.468-2.63z" />
          <path fill-rule="evenodd" d="M8 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
          <path fill-rule="evenodd" d="M8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1zM0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8z" />
        </svg>
      </a>

      <!-- Login / Logout / User Information -->
      <div class="position-absolute bg-white shadow text-center" id="div2">

        <!-- Logined -->
        <?php
        if (isset($_SESSION["userID"])) {
          echo "
            <div id='userControl'>
              <a class='text-dark text-center loginLabel' href='./userCenter.php?page=userCenter'>Person Center</a>
              <a class='text-dark text-center loginLabel' href='./userCenter_Order.php?page=UserOrder'>Order Record</a>
              <a class='text-dark text-center loginLabel' href='./userCenter_CustomerProduct.php?page=Products'>My Products</a>
             
              <div style='width:100%;height: 40px'></div>
              <a class='text-dark text-center loginLabel' onclick='logout()'><label>Logout</label>
                <svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' fill='currentColor' class='bi bi-box-arrow-right' viewBox='0 0 16 16'>
                  <path fill-rule='evenodd' d='M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0v2z'/>
                  <path fill-rule='evenodd' d='M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z'/>
                </svg>
              </a>
              
            </div>
          ";
        } else {
          echo '
          <div id="loginControl">
            <img src="https://i.imgur.com/EaLT6rm.jpg" width="100%" id="img3">
            <input type="button" class="float-left btn btn-info w-50 rounded-0 border-0 user_if" value="Login" data-toggle="modal" data-target="#login">
            <input type="button" class="float-left btn btn-info w-50 rounded-0 border-0 user_if" value="Register" data-toggle="modal" data-target="#register">
          </div>
          ';
        }
        ?>
      </div>
      <?php
        if (isset($_SESSION["userID"])){
          echo '
            <a class="navbar-brand" href="./shoppingCart.php?page=cart" id="userControl_">
              <svg width="35px" height="35px" viewBox="0 0 16 16" class="bi bi-cart-dash" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z" />
                <path fill-rule="evenodd" d="M6 7.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5z" />
              </svg>
            </a>
          ';
        }else{
          echo '
            <contact id="loginControl_">
              <button type="button" class="btn text-primary table-hover shadow-none" style="width: 51px;" data-toggle="modal" data-target="#login">
                <span data-toggle="tooltip" data-placement="top" title="Login">Login</span>
              </button>
              <button type="button" class="btn text-primary table-hover shadow-none" style="width: auto;" data-toggle="modal" data-target="#register">
                <span data-toggle="tooltip" data-placement="top" title="Register">Register</span>
              </button>
            </contact>
          ';
        }
      ?>
    </div>
  </div>
</nav>