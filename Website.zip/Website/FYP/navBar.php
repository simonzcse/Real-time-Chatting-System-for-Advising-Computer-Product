<?php
$action = $_GET["page"] ?? "homePage";
?>

<ul class="nav nav-fill nav-pills justify-content-center">
    <li class="nav-item">
        <a class="nav-link btn btn-outline-primary rounded-0 border-0 shadow-sm 
        <?php if ($action == "homePage") {
            echo "active";
        } ?> " href="index.php?page=homePage">Home Page</a>
    </li>
    <li class="nav-item">
        <a class="nav-link btn btn-outline-primary rounded-0 border-0 shadow-sm
        <?php if ($action == "computerBuilder") {
            echo "active";
        } ?> " href="computerBuild.php?page=computerBuilder">Computer Builder</a>
    </li>
    <li class="nav-item rounded-0">
        <a class="nav-link btn btn-outline-primary rounded-0 border-0 shadow-sm
        <?php if ($action == "productList") {
            echo "active";
        } ?> " href="productGuide.php?page=productList">Product Guide</a>
    </li>
    <li class="nav-item rounded-0">
        <a class="nav-link btn btn-outline-primary rounded-0 border-0 shadow-sm
        <?php if ($action == "aboutUs") {
            echo "active";
        } ?> " href="contact.php?page=aboutUs">Contact US</a>
    </li>
</ul>