<?php
require __DIR__ . '/vendor/autoload.php';
use Kreait\Firebase\Factory;
putenv('SUPPRESS_GCLOUD_CREDS_WARNING=true');
$factory = (new Factory())->withProjectId("fyp-project-500c0");



$storage = $factory->createStorage();
$storageClient = $storage->getBucket();
?>
<script>
</script>