<?php

require __DIR__ . '/vendor/autoload.php';

use Kreait\Firebase\Factory;
include "./productDB.php";
function getUserData($userID) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
            ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('customer/');
    $data = $reference->getValue();

    foreach ($data as $value) {
        if ($value["customer_id"] == $userID) {
            $array = array();
            $array["customer_id"] = $value["customer_id"];
            $array["first_name"] = $value["first_name"];
            $array["last_name"] = $value["last_name"];
            $array["email_id"] = $value["email_id"];
            $array["password"] = $value["password"];
            $array["imageURL"] = $value["imageURL"];
            $array["address"] = $value["address"];
            return $array;
        }
    }
    return "User Not found!";
}

function getOrders($userID) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
            ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('bill/');
    $data = $reference->getValue();
    $count = 0;
    $price = 0;
    $OrderNumber = "0";
    foreach ($data as $value) {
        if ($value["customer_id"] == $userID) {
            $productData = getProductData($value['productForBill']['id'], NULL);
            if ($count == 0){
                $IDNumber = "a" . strval($count);
                $OrderNumber = $value["orderID"];
                $price = getOrderTotalPrice($OrderNumber);
                echo "
                <div type='button' class='collapsible'>
                    <div class='row p-3 h-100'>
                        <div class='col-8'>
                            <div class='text-muted col-5 d-inline-block'>
                                ORDER PLACED<br>
                                {$value["orderDate"]}
                            </div>
                            <div class='text-muted col-3 d-inline-block'>
                                TOTAL<br>
                                \${$price}
                            </div>
                        </div>
                        <div class='col-4 text-muted text-right'>
                            ORDER #{$OrderNumber}<br>
                            <a href='#' data-toggle='modal' data-toggle='modal' data-target='#{$IDNumber}'>Order Details</a>
                            <a href='#' class='ml-4'>Invoice</a>
                        </div>
                    </div>
                </div>
                ";
                echo "            <div class='content'>";
                getOrderProducts($OrderNumber);
                echo "</div>";
                echo "
                        <div class='modal fade' id='{$IDNumber}' tabindex='-1' role='dialog' aria-labelledby='exampleModalCenterTitle' aria-hidden='true'>
        <div class='modal-dialog modal-dialog-centered' role='document'>
            <div class='modal-content'>
                <div class='modal-header'>
                    <h5 class='modal-title' id='exampleModalLongTitle'>Order Details</h5>
                    <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>
                <div class='modal-body'>
                    <h6>Deliver Address :</h6>
                    <div class='form-group row'>
                        <label class='col-sm-2 col-form-label'>Country: </label>
                        <div class='col-sm-10''>
                            <input type='text'class='text-muted form-control-plaintext' value='{$value["deliver_address"]["Country"]}' readonly>
                        </div>
                    </div>
                    <div class='form-group row'>
                        <label  class='col-sm-2 col-form-label'>City: </label>
                        <div class='col-sm-10'>
                            <input type='text'  class='text-muted form-control-plaintext' value='{$value["deliver_address"]["City"]}' readonly>
                        </div>
                    </div>
                    <div class='form-group row'>
                        <label class='col-sm-2 col-form-label'>Road: </label>
                        <div class='col-sm-10'>
                            <input type='text'  class='text-muted form-control-plaintext' value='{$value["deliver_address"]["Road"]}' readonly>
                        </div>
                    </div>
                    <h6>Payment Method :</h6>
                    <div class='form-group row'>
                        <div class='col-sm-10'>
                            <input type='text'  class='text-muted form-control-plaintext' value='{$value["paymentType"]}' readonly>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
                ";
                $count++;
            }else {
                $IDNumber = "a" . strval($count);
                if ($value["orderID"] != $OrderNumber) {
                    $OrderNumber = $value["orderID"];
                    $price = getOrderTotalPrice($OrderNumber);
                    echo "
                <div type='button' class='collapsible'>
                    <div class='row p-3 h-100'>
                        <div class='col-8'>
                            <div class='text-muted col-5 d-inline-block'>
                                ORDER PLACED<br>
                                {$value["orderDate"]}
                            </div>
                            <div class='text-muted col-3 d-inline-block'>
                                TOTAL<br>
                                \${$price}
                            </div>
                        </div>
                        <div class='col-4 text-muted text-right'>
                            ORDER {$OrderNumber}<br>
                            <a href='#' data-toggle='modal' data-target='#{$IDNumber}'>Order Details</a>
                            <a href='#' class='ml-4'>Invoice</a>
                        </div>
                    </div>
                </div>
                ";
                    echo "            <div class='content'>";
                    getOrderProducts($OrderNumber);
                    echo "</div>";
                    echo "
                        <div class='modal fade' id='{$IDNumber}' tabindex='-1' role='dialog' aria-labelledby='exampleModalCenterTitle' aria-hidden='true'>
        <div class='modal-dialog modal-dialog-centered' role='document'>
            <div class='modal-content'>
                <div class='modal-header'>
                    <h5 class='modal-title' id='exampleModalLongTitle'>Modal title</h5>
                    <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>
                <div class='modal-body'>
                    <h6>Deliver Address :</h6>
                    <div class='form-group row'>
                        <label class='col-sm-2 col-form-label'>Country: </label>
                        <div class='col-sm-10''>
                            <input type='text'class='text-muted form-control-plaintext' value='{$value["deliver_address"]["Country"]}' readonly>
                        </div>
                    </div>
                    <div class='form-group row'>
                        <label  class='col-sm-2 col-form-label'>City: </label>
                        <div class='col-sm-10'>
                            <input type='text'  class='text-muted form-control-plaintext' value='{$value["deliver_address"]["City"]}' readonly>
                        </div>
                    </div>
                    <div class='form-group row'>
                        <label class='col-sm-2 col-form-label'>Road: </label>
                        <div class='col-sm-10'>
                            <input type='text'  class='text-muted form-control-plaintext' value='{$value["deliver_address"]["Road"]}' readonly>
                        </div>
                    </div>
                    <h6>Payment Method :</h6>
                    <div class='form-group row'>
                        <div class='col-sm-10'>
                            <input type='text'  class='text-muted form-control-plaintext' value='{$value["paymentType"]}' readonly>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
                ";
                $count++;
                }
            }
        }
    }
    echo "";
}

function upDateData($customer_id, $email_id, $first_name, $last_name, $imageURL, $password, $address = NULL) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
        ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('customer/');
    $data = $reference->getValue();
    if (!($address)) {
        $address["city"] = "No City";
        $address["country"] = "No Country";
        $address["road"] = "No Road";
    }
    $postData = [
        "customer_id" => $customer_id,
        "email_id" => $email_id,
        "first_name" => $first_name,
        "imageURL" => $imageURL,
        "last_name" => $last_name,
        "password" => $password,
        "username" => "$first_name $last_name",
        "address" => [
            "city" => $address["city"],
            "country" => $address["country"],
            "road" => $address["road"]
        ],
        "role" => "Customer",
        "mobile" => "93359718",
        "status" => "off"
    ];

    $postRef = $database->getReference('customer/' . $customer_id)->set($postData);
}

function getOrderTotalPrice($orderID) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
        ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('bill/');
    $data = $reference->getValue();
    $price = 0;
    foreach ($data as $value) {
        if ($value["orderID"] == $orderID) {
            $productData = getProductData($value['productForBill']['id'], NULL);
            $price += $value['productForBill']['Qty'] * $productData["priceForEach"];
        }
    }
    return $price;
}

function getOrderProducts($orderID) {
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
        ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('bill/');
    $data = $reference->getValue();
    $price = 0;
    $count = 0;
    foreach ($data as $value) {
        if ($value["orderID"] == $orderID) {
            $productData = getProductData($value['productForBill']['id'], NULL);
            if ($count == 0){
                echo "
                <span><h4>{$value["orderDate"]}</h4></span>
            <label class='text-muted'>Your can check the product here.</label>
    ";
                $count++;
            }

            echo "
                <div class='p-2'>
                    <div>
                        <img class='float-left' src='{$productData['imgURL']}' width='150px'>
                        <label style='color: #6086ea'><h5>{$productData['name']}</h5></label><br>
                        <label class='text-muted mb-0'>Quantity: </label> {$value['productForBill']['Qty']}<br>
                        <label class='text-danger'>\${$productData['priceForEach']}</label><br>
                        <a class='btn btn-success' href='./productPage.php?productID={$productData["id"]}&selectOption=AllProduct&page=productList'>Buy it again</a>
                    </div>
                </div>
            <hr>
            ";
        }
    }
}
function paymentListCart()
{
    $totalPrice = 0;
    $userID = $_SESSION["userID"] ?? NULL;
    $factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
    $factory = (new Factory())
        ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

    $database = $factory->createDatabase();

    $reference = $database->getReference('cart/');
    $data = $reference->getValue();

    foreach ($data as $value) {
        if ($value["customer_id"] == $userID) {
            $productData = getProductData($value['productForCart']['id']);
            echo "
            <div>
                <img class='float-left mr-3' src='{$productData['imgURL']}' width='120px'>
                <label style='color: #6086ea'><h5>{$productData['name']}</h5></label><br>
                <label class='text-muted mb-0'>Quantity: </label> {$value['productForCart']['Qty']}<br>
                <label class='text-danger'>\${$productData['priceForEach']}</label><br>
            </div><br>
            <hr>
            ";
            $totalPrice += $value['productForCart']['Qty'] * $productData['priceForEach'];
        }
    }
    echo "
    <h2 class='text-danger'>Total Price: \${$totalPrice}</h2>
    ";

}
?>