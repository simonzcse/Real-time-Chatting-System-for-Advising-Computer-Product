<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
    <title>PC Building - My Products</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/addition.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css"
          integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/3171b0b8ab.js" crossorigin="anonymous"></script>
</head>
<style>
    * {
        margin: 0;

    }
    .productPhoto {
        position: absolute;
        margin: 0 auto;
        border: 1px solid #dedede;
        width: 90%;
        height: 100%;
    }
    #addPhoto {
        position: absolute;
        font-size: 50px;
        color: gray;
        z-index: 999;
        width: 90%;
        height: 100%;
        border: 1px solid #dedede;
        background: none;
    }
    #addPhoto:focus {
        outline: none;
    }
    #addPhoto:hover {
        background: rgba(245,245,245, 0.5);
    }

    input[type=radio] {
        position: absolute;
        top: 0;
        cursor: pointer;
        display: block;
        width: 100%;
        height: 100%;
        border: 1px solid #c9c9c9;
        -webkit-appearance: none;
        z-index: 0;
    }

    input[type=radio]:checked {
        border: 2px solid #005358;
    }

    input[type=radio]:focus {
        outline: none;
    }

</style>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-app.js"></script>

<!-- If you enabled Analytics in your project, add the Firebase SDK for Analytics -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-analytics.js"></script>

<!-- Add Firebase products that you want to use -->
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-database.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.2.5/firebase-storage.js"></script>
<script src="fireBaseConfig.js"></script>
<script src="accountManagement.js"></script>
<script src="divControl.js"></script>

<script>
    var ImgName;
    var files = [];
    var id = makeid(20);

    function addPhoto() {
        var input = document.createElement("input");
        input.type = "file";
        input.click();
        input.onchange = e => {
            files = e.target.files;
            reader = new FileReader();
            reader.onload = function () {
                document.getElementById("myimg").src = reader.result;
            }
            reader.readAsDataURL(files[0]);
            submitPhoto();
        }
    }

    function submitPhoto() {
        var uploadTask = firebase.storage().ref("Product Images/" + id+".png").put(files[0]);

        uploadTask.on("statechange", function(snapshot) {

            },
            function (error) {
                alert(error);
            },
            function () {
                var ref = firebase.database().ref("product");
                ref.once("value")
                    .then(function(value) {
                        console.log(value.numChildren());
                        uploadTask.snapshot.ref.getDownloadURL().then(function (url){
                            firebase.database().ref("Product Image/").set({
                                imageURL: url
                            })
                        });
                    });

            },
        )
    }

    function makeid(length) {
        var result           = [];
        var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for ( var i = 0; i < length; i++ ) {
            result.push(characters.charAt(Math.floor(Math.random() *
                charactersLength)));
        }
        return result.join('');
    }
</script>
<body onload="loadChat()">
<?php
include "./login.html";
include "./register.html";
include "./header.php";
include "./navBar.php";
include "./productDB.php";
?>
<?php
$productData = getProductData($_GET["productID"], null);
?>
<div style="height: auto;min-height:800px;background-color: #f5f5f5">
    <div class="container" style="height: 100%;min-height: 800px; background-color: white">
        <div style="height: 33px; line-height: 33px">
            <a href="./userCenter_CustomerProduct.php?page=userCenter">My Products</a> <span style="font-size: 10px">></span><span class="text-muted">Product Edit</span>
        </div>
        <hr>
        <div class="position-relative float-lg-left d-lg-block d-none" style="height: 250px; width: 25%;">
            <br>
            <img class="productPhoto" width="100%" id="myimg" src="<?= $productData["imgURL"] ?>">
            <button id="addPhoto" onclick="addPhoto()">+</button><br>
        </div>
        <div class="position-relative float-lg-left d-md-block d-lg-none" style="height: 250px; width: 100%;">
            <br>
            <img class="productPhoto" width="100%" id="myimg">
            <button id="addPhoto" onclick="addPhoto()">+</button>
        </div>
        <div class="d-md-block d-lg-none">
            <br><br><br>
        </div>
        <form class="float-lg-left" style="width: 70%;" autocomplete="off" action="editProductProcess.php?productID=<?= $_GET["productID"] ?>&productImg=<?= $productData["imgURL"] ?>" method="post">
            <label>Product Name:</label>
            <input type="text" class="form-control" name="name" value="<?= $productData["name"] ?>" required><br><hr>
            <label>Product Type</label><br>
            <div style="height: 50px;width: 100px;background-image: url(https://i.imgur.com/xcaUeU2.jpg); background-repeat: no-repeat;background-position: center center" class="d-inline-block position-relative">
                <input type="radio" name="rg1" value="CPU" required <?= checkCPU($productData["type"]) ?>>
            </div>
            <div style="height: 50px;width: 100px;background-image: url(https://i.imgur.com/xg3Ia5i.jpg); background-repeat: no-repeat;background-position: center center" class="d-inline-block position-relative">
                <input type="radio" name="rg1" value="Motherboard" <?= checkMB($productData["type"]) ?>>
            </div>
            <div style="height: 50px;width: 100px;background-image: url(https://i.imgur.com/MInrhxg.jpg); background-repeat: no-repeat;background-position: center center" class="d-inline-block position-relative">
                <input type="radio" name="rg1" value="RAM" <?= checkRAM($productData["type"]) ?>>
            </div>
            <div style="height: 50px;width: 100px;background-image: url(https://i.imgur.com/5wdPSih.jpg); background-repeat: no-repeat;background-position: center center" class="d-inline-block position-relative">
                <input type="radio" name="rg1" value="GPU" <?= checkGPU($productData["type"]) ?>>
            </div>
            <div style="height: 50px;width: 100px;background-image: url(https://i.imgur.com/yGlcl86.jpg); background-repeat: no-repeat;background-position: center center" class="d-inline-block position-relative">
                <input type="radio" name="rg1" value="Case" <?= checkCase($productData["type"]) ?>>
            </div>
            <div style="height: 50px;width: 100px;background-image: url(https://i.imgur.com/o9tXkjv.jpg); background-repeat: no-repeat;background-position: center center" class="d-inline-block position-relative">
                <input type="radio" name="rg1" value="Power" <?= checkPower($productData["type"]) ?>>
            </div>
            <div style="height: 50px;width: 100px;background-image: url(https://i.imgur.com/0RUNV9o.jpg); background-repeat: no-repeat;background-position: center center" class="d-inline-block position-relative">
                <input type="radio" name="rg1" value="Storage" <?= checkStorage($productData["type"]) ?>>
            </div>
            <div style="height: 50px;width: 100px;background-image: url(https://i.imgur.com/CSzZImG.jpg); background-repeat: no-repeat;background-position: center center" class="d-inline-block position-relative">
                <input type="radio" name="rg1" value="Water Cooling" <?= checkCPUCase($productData["type"]) ?>>
            </div>
            <div style="height: 50px;width: 100px;background-image: url(https://i.imgur.com/uGS4fog.jpg); background-repeat: no-repeat;background-position: center center" class="d-inline-block position-relative">
                <input type="radio" name="rg1" value="OS System" <?= checkOS($productData["type"]) ?>>
            </div><br><hr>
            <label>Product Price</label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">$</span>
                </div>
                <input type="text" class="form-control" aria-label="Amount (to the nearest dollar)" name="price" value="<?= $productData["priceForEach"] ?>" required>
            </div><br><hr>
            Description<br>
            <div class="form-group">
                <textarea class="form-control" id="exampleFormControlTextarea3" rows="5" name="desc" required><?= $productData["description"] ?></textarea>
            </div><br>
            <button class="btn btn-success btn-block">Submit</button>
        </form>
    </div>
</div>


<!-- Footer -->
<footer class="container-fluid bg-dark">
    <div class="container">
        <div class="row text-light pb-5">
            <div class="col-6 mt-3 d-flex flex-row">
                <img src="https://i.imgur.com/qZOXoGH.png" width="80px" class="d-none d-md-none d-lg-block"><label
                        class="m-3">
                    <h4>PC Building</h4>
                </label>
            </div>
            <div class="col-6 text-light mt-4">
                <label>
                    <h3>Final Year Project</h3>
                    Title : A Real-time Chatting System for Advising Computer Products
                </label>
            </div>
        </div>
    </div>
</footer>
<?php
function checkCPU($value) {
    if ($value == "CPU") {
        echo "checked";
    }
}
function checkMB($value) {
    if ($value == "Motherboard") {
        echo "checked";
    }
}
function checkRAM($value) {
    if ($value == "RAM") {
        echo "checked";
    }
}
function checkGPU($value) {
    if ($value == "GPU") {
        echo "checked";
    }
}
function checkCase($value) {
    if ($value == "Case") {
        echo "checked";
    }
}
function checkPower($value) {
    if ($value == "Power") {
        echo "checked";
    }
}
function checkStorage($value) {
    if ($value == "Storage") {
        echo "checked";
    }
}
function checkCPUCase($value) {
    if ($value == "Water Cooling") {
        echo "checked";
    }
}
function checkOS($value) {
    if ($value == "OS System") {
        echo "checked";
    }
}
?>
<!-- Chat bot -->
<script>
    function loadChat() {
        $("#chatbot").load("ChatBot%20UI.html");
    }
</script>
<div id="chatbot"></div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>

<!-- Bootstrap core JavaScript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
</body>


</html>