<?php
require __DIR__ . '/vendor/autoload.php';

use Kreait\Firebase\Factory;
session_start();
$qty = $_POST["qty"] ?? NULL;
$productID = $_POST["productID"] ?? NULL;

if (isset($_SESSION["userID"])) {
    $userID = $_SESSION["userID"];
}

$factory = (new Factory)->withServiceAccount('./fast-environs-300506-firebase-adminsdk-m7yxi-38ae4fde91.json');
$factory = (new Factory())
    ->withDatabaseUri('https://fyp-project-500c0-default-rtdb.firebaseio.com');

$database = $factory->createDatabase();

$reference = $database->getReference('cart/');
$data = $reference->getValue();

$array = $_SESSION["shopCart"];
if ($data != NULL) {
    foreach ($data as $key=>$value){
        $array_count = $key;
    }
    $array_count++;
} else {
    $array_count = 0;
}

foreach ($array as $key=>$value)
{
    $postData = [
        "customer_id" => $userID,
        "productForCart" => [
            "Qty" => 1,
            "id" => $value
        ],
    ];

    $postRef = $database->getReference('cart/'.$array_count)->set($postData);
    $array_count++;
}
?>
<?php
unset($_SESSION["totalPrice"]);
unset($_SESSION["shopCart"]);
unset($_SESSION["CPU"]);
unset($_SESSION["Motherboard"]);
unset($_SESSION["RAM"]);
unset($_SESSION["GPU"]);
unset($_SESSION["Case"]);
unset($_SESSION["Power"]);
unset($_SESSION["Storage"]);
unset($_SESSION["CPU Case"]);
unset($_SESSION["OS System"]);
?>
<script>
    alert("Add to cart successfully");
    history.go(-1);
</script>